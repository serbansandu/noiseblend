from noiseblend_api.api import serve
serve()