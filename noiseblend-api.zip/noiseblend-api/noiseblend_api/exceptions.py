class NoDeviceAvailable(Exception):
    """When no device was available for playback"""
