DELETE
FROM blends
WHERE "user" = '9f56d189-be7e-42e0-bf8a-ab3c4d5292f2';


DELETE
FROM app_users
WHERE id = '9f56d189-be7e-42e0-bf8a-ab3c4d5292f2';


DELETE
FROM images
WHERE "user" = '9f56d189-be7e-42e0-bf8a-ab3c4d5292f2';


DELETE
FROM spotify_users
WHERE "user" = '9f56d189-be7e-42e0-bf8a-ab3c4d5292f2';


DELETE
FROM users
WHERE id = '9f56d189-be7e-42e0-bf8a-ab3c4d5292f2';