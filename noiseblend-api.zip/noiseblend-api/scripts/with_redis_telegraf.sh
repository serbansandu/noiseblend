#!/bin/sh
redis-server &
telegraf --config "$TELEGRAF_CONFIG" &
exec "$@"