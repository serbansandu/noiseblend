CREATE SCHEMA IF NOT EXISTS pganalyze;


CREATE EXTENSION IF NOT EXISTS pg_stat_statements;


CREATE EXTENSION IF NOT EXISTS pgcrypto;


CREATE OR REPLACE FUNCTION pganalyze.get_stat_statements(showtext boolean = TRUE) RETURNS
SETOF pg_stat_statements AS $$
  /* pganalyze-collector */ SELECT * FROM public.pg_stat_statements(showtext);
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;


CREATE OR REPLACE FUNCTION pganalyze.get_stat_activity() RETURNS
SETOF pg_stat_activity AS $$
  /* pganalyze-collector */ SELECT * FROM pg_catalog.pg_stat_activity;
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;


CREATE OR REPLACE FUNCTION pganalyze.get_column_stats() RETURNS
SETOF pg_stats AS $$
  /* pganalyze-collector */ SELECT schemaname, tablename, attname, inherited, null_frac, avg_width,
  n_distinct, NULL::anyarray, most_common_freqs, NULL::anyarray, correlation, NULL::anyarray,
  most_common_elem_freqs, elem_count_histogram
  FROM pg_catalog.pg_stats;
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;


CREATE OR REPLACE FUNCTION pganalyze.get_stat_replication() RETURNS
SETOF pg_stat_replication AS $$
  /* pganalyze-collector */ SELECT * FROM pg_catalog.pg_stat_replication;
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;


CREATE USER pganalyze WITH PASSWORD '6779f0a9-ee21-4c47-ac91-45e7ff87a022' CONNECTION
LIMIT 5;

REVOKE ALL ON SCHEMA PUBLIC
FROM pganalyze;

GRANT USAGE ON SCHEMA pganalyze TO pganalyze;


CREATE OR REPLACE FUNCTION pganalyze.get_stat_progress_vacuum() RETURNS
SETOF pg_stat_progress_vacuum AS $$
  /* pganalyze-collector */ SELECT * FROM pg_catalog.pg_stat_progress_vacuum;
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;


CREATE EXTENSION IF NOT EXISTS pg_buffercache;


CREATE OR REPLACE FUNCTION pganalyze.get_buffercache() RETURNS
SETOF public.pg_buffercache AS $$
  /* pganalyze-collector */ SELECT * FROM public.pg_buffercache;
$$ LANGUAGE SQL VOLATILE SECURITY DEFINER;