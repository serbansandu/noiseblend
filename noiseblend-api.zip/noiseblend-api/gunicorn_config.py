# from hwinfo import hardware_info

# try:
#     hwinfo = hardware_info()
#     print('Hardware Info:', hwinfo)
# except:
#     hwinfo = {}

# workers = hwinfo.get('cpus', 1)
import os

bind = os.getenv("GUNICORN_BIND", "0.0.0.0:9000")
workers = 1
worker_class = "sanic.worker.GunicornWorker"
pidfile = "gunicorn.pid"
max_requests = 300
