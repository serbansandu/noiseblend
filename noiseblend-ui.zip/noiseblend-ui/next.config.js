const withBundleAnalyzer = require('@zeit/next-bundle-analyzer')
const withCoffeescript = require('next-coffeescript')
const withTM = require('@weco/next-plugin-transpile-modules')
const withSourceMaps = require('@zeit/next-source-maps')
const withOffline = require('next-offline')
const withProgressBar = require('next-progressbar')
const LodashModuleReplacementPlugin = require('lodash-webpack-plugin')
const webpack = require('webpack')
const { PHASE_DEVELOPMENT_SERVER } = require('next/constants')
// const SentryPlugin = require('webpack-sentry-plugin')

const TEST_MODE = process.env.TEST_MODE === 'true'

module.exports = (phase, { defaultConfig }) => {
    const apiDomain =
        phase === PHASE_DEVELOPMENT_SERVER ? 'localhost:9000' : TEST_MODE ? 'api-test.noiseblend.com' : 'api.noiseblend.com'
    const domain = phase === PHASE_DEVELOPMENT_SERVER ? 'localhost' : 'www.noiseblend.com'
    return withProgressBar(
        withOffline(
            withSourceMaps(
                withTM(
                    withBundleAnalyzer(
                        withCoffeescript({
                            ...defaultConfig,
                            publicRuntimeConfig: {
                                debug: phase === PHASE_DEVELOPMENT_SERVER,
                                domain: domain,
                                staticDir:
                                    phase === PHASE_DEVELOPMENT_SERVER ? '/static' : 'https://static.noiseblend.com',
                                sentryDSN:
                                    phase === PHASE_DEVELOPMENT_SERVER
                                        ? 'https://243b8e532c964e67a9571c2244b74985@sentry.io/1216889'
                                        : 'https://3ce14c5eda584570954a7ba2156bb0af@sentry.io/1209883',
                                apiURL:
                                    phase === PHASE_DEVELOPMENT_SERVER
                                        ? `http://${apiDomain}/`
                                        : `https://${apiDomain}/`,
                                wsURL: phase === PHASE_DEVELOPMENT_SERVER ? `ws://${apiDomain}` : `wss://${apiDomain}`,
                                gitSHA: process.env.GIT_SHA,
                            },
                            cssModules: true,
                            transpileModules: ['react-popper'],
                            analyzeServer: ['server', 'both'].includes(process.env.BUNDLE_ANALYZE),
                            analyzeBrowser: ['browser', 'both'].includes(process.env.BUNDLE_ANALYZE),
                            webpack(config, { dev, isServer }) {
                                console.log('Mode: %s', isServer ? 'Server' : 'Client')
                                console.log('    Environment: %s', process.env.NODE_ENV)
                                console.log('    Development: %s', dev)
                                // if (dev) {
                                //     config.devtool = 'cheap-module-eval-source-map'
                                // }
                                config.module.rules.push({
                                    test: /\.(png|jpg|gif|eot|ttf|woff|woff2)$/,
                                    use: { loader: 'url-loader', options: { limit: 100000 } },
                                })
                                config.module.rules.push({
                                    test: /\.json$/,
                                    loader: 'json-loader',
                                })
                                config.module.rules.push({
                                    test: /\.svg$/,
                                    exclude: /node_modules/,
                                    loader: 'svg-react-loader',
                                    query: {
                                        classIdPrefix: '[name]-[hash:8]__',
                                        filters: [],
                                        propsMap: {
                                            fillRule: 'fill-rule',
                                            size: 'width',
                                            color: 'stroke',
                                        },
                                        xmlnsTest: /^xmlns.*$/,
                                    },
                                })

                                config.plugins.push(new webpack.IgnorePlugin(/^raven$/))
                                config.plugins.push(new LodashModuleReplacementPlugin({ shorthands: true }))
                                if (!dev) {
                                    config.plugins.push(new webpack.IgnorePlugin(/^reactotron.*/))
                                }
                                return config
                            },
                        })
                    )
                )
            )
        )
    )
}
